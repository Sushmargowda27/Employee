package com.emp.EmployeeDetails;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController 
{
	@Autowired
	private EmployeeRepository emprep;
	
//	@Autowired
//	private Employee empentity;
	
	@RequestMapping("/save")
	public Employee save(@RequestBody Employee emp)
	{
		Employee emp1=emprep.save(emp);
		return emp1;
	}
	@GetMapping("/get")
	public List<Employee> get()
	{
		return emprep.findAll();
	}
	@GetMapping("/get/{id}")
	public Optional<Employee> getById(@PathVariable int id)
	{
		return emprep.findById(id);
	}
	@PutMapping("/update")
	public Employee updateById(@RequestParam int id, @RequestBody Employee emp1)
	{
		emprep.findById(id);
		return emprep.save(emp1);
	}
//	@PutMapping("/update")
//	public Employee updateByName(@RequestParam int id, @RequestParam String name, @RequestBody Employee emp2)
//	{
//		emprep.findById(id);
//		empentity.setName(name);
//		return emprep.save(emp2);
//	}
}
